# Academic Revision Assistant — Shareable Skill

A standalone Skill converted from the user's **Academic Revision Assistant** personal plugin.

## Included capabilities
- Academic language editing with scientific and logical critique.
- SCI section-specific guidance for Abstract, Introduction, Materials and Methods, Results, Discussion, and Conclusion.
- Critique-first, three-column sentence-level revision table.
- Reviewer-response assistance and Chinese translation on request.

## Sharing and installing
- Share this ZIP file directly, or publish it in a repository accessible to intended users.
- In ChatGPT, go to Plugins → Skills → Create → Upload from your computer (where this feature is available), and select this ZIP.
- For other Skill-compatible environments, extract the `academic-revision-assistant` folder to the local skills directory.

## Important distinction
Sharing this Skill ZIP does **not** change the public/private visibility of the original personal Plugin. Public listing of a Plugin requires the platform's submission and approval process.

## Provenance
Converted from the Academic Revision Assistant Plugin's instructions and interface, with reorganized guidance for independent Skill use. The original plugin content does not require an external service or knowledge-base attachment.
